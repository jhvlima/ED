/**
 * @file arvoreHuffman.c
 * @brief Arquivo fonte para o TAD a arvore Huffman
 *
 *
 * @author Gabriel de Albuquerque
 * @author Joao Henrique
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "arvoreHuffman.h"

int eof = -1;
// Função para codificar o arquivo usando os códigos de Huffman
void codificarArquivo(FILE *infile, FILE *outfile, char *codes[], bitmap *bm, unsigned char *current_byte, unsigned int *nbits)
{
    unsigned char caracter;
    char *string;
    printf("eof:%d/%s\n", eof, codes[eof]);

    while (1)
    {
        // le um caracter
        caracter = fgetc(infile);
        if (feof(infile))
            break;

        // Put the corresponding bitstring on outfile
        for (string = codes[caracter]; *string; string++)
            insereBitNoByte(bm, *string, current_byte, nbits);
    }
    

   
    for (string = codes[eof];*string; string++)
        insereBitNoByte(bm, *string, current_byte, nbits);

    // Finish off the last byte and write the bitmap to the file
    imprimeBitmap(outfile, bm, current_byte, nbits);
}

int preencheVetorPesos(int vetor[], FILE *arquivo)
{
    int n = 0;
    assert(arquivo != NULL, "ERRRO AO ABRIR ARQUIVO DE ENTRADA");
    unsigned char carcter;
    while (fread(&carcter, 1, 1, arquivo) > 0)
    {
        assert(carcter < QNT_CARACTERES, "CARACTER MAIOR QUE 256");
        vetor[carcter]++;
        n++;
    }

    return n;
}

/*-------------------------| Arvore |---------------------------*/

struct _tArv
{
    int ocorrencia;
    int caracter;
    tArv *dir;
    tArv *esq;
};


/**
 *
 * @brief Cria a lista de arvores, comecando com todas elas sendo folhas, e postoeriormente será unido as duas menores frequencias ao uma nova arvore pai
 */
tLista *tListaCriaArvoresHuff(int *vetorPeso)
{
    tLista *listaFolhas = tListaCriaVazia();
    int i;
    for (i = 0; i < QNT_CARACTERES; i++)
    {
        if (vetorPeso[i] > 0)
        {
            tArv *novaFolha = tArvCriaVazia();
            novaFolha->caracter = i;
            novaFolha->ocorrencia = vetorPeso[i];
            tListaInsere(listaFolhas, novaFolha);
        }
    }
    for (i = 0; i < QNT_CARACTERES; i++)
    {
        if(vetorPeso[i] == 0)
        {
            tArv *novaFolha = tArvCriaVazia();
            novaFolha->caracter = i;
            novaFolha->ocorrencia = 0;
            eof = i;
            tListaInsere(listaFolhas, novaFolha);
            break;
        }
    }

    return listaFolhas;
}

/**
 *
 * @return retorna retorna negativo se a2 > a1, se nao retorna positvo
 */
int tArvCompara(void *a1, void *a2)
{
    tArv *arv1 = (tArv *)a1;
    tArv *arv2 = (tArv *)a2;
    return arv1->ocorrencia - arv2->ocorrencia;
}

/**
 *
 * @brief Cria a lista de arvores, comecando com todas elas sendo folhas, e postoeriormente será unido as duas menores frequencias ao uma nova arvore pai
 */
tArv *tArvCriaArvoreHuff(int *vetorPeso)
{
    tLista *listaFolhas = tListaCriaArvoresHuff(vetorPeso);
    tArv *a = NULL;
    while (tListaTamanho(listaFolhas) > 1)
    {
        tListaOrdena(listaFolhas, tArvCompara);
        tArv *menor1 = tListaRetiraMenor(listaFolhas, tArvCompara);
        tArv *menor2 = tListaRetiraMenor(listaFolhas, tArvCompara);
        a = tArvInsere(menor2, menor1);
        tListaInsere(listaFolhas, a);
    }
    tListaLibera(listaFolhas);
    return a;
}

tArv *tArvCriaVazia()
{
    tArv *a = calloc(1, sizeof(tArv));
    return a;
}

tArv *tArvInsere(tArv *d, tArv *e)
{
    tArv *caule = tArvCriaVazia();
    caule->dir = d;
    caule->esq = e;
    caule->ocorrencia = d->ocorrencia + e->ocorrencia;
    return caule;
}


void tArvLibera(tArv *a)
{
    if (!tArvEhVazia(a))
    {
        tArvLibera(a->dir);
        tArvLibera(a->esq);
        free(a);
    }
}

int tArvEhVazia(tArv *a)
{
    return a == NULL;
}

// funcao para ver como a arvore ficou no terminal
void printHelper(tArv *a, int space)
{
    if (a == NULL)
    {
        return;
    }

    // Increase distance between levels
    space += 10;

    // Print right child first
    printHelper(a->dir, space);

    // Print current node after space
    printf("\n");
    for (int i = 10; i < space; i++)
    {
        printf(" ");
    }
        if (a -> caracter == eof)
        {
            printf("eof aqui: %d", eof);
        }
    printf("|%d (%c)|\n", a->ocorrencia, a->caracter);

    // Print left child
    printHelper(a->esq, space);
}

void tArvImprime(tArv *a)
{
    printHelper(a, 0);
    /* printf("IMPRIMINDO ARVORE\n");
    if (!tArvEhVazia(a))
    {
        // printf("CARACTER: %c | OCORRENCIA: %d\n", a->caracter, a->ocorrencia);
        printf("<|%d|", a->ocorrencia);
        tArvImprime(a->dir);
        tArvImprime(a->esq);
        printf(">");
    }*/
}

void travessia(tArv *arv, int level, char *code_so_far, char **codes)
{
    if(arv == NULL)
        return;
    // se é folha, entao para a termina a sequencia de bits
    if (tArvEhFolha(arv))
    {
        code_so_far[level] = 0;
        codes[arv->caracter] = strdup(code_so_far);
        printf("CODE: %s       CAR: %c\n", code_so_far, arv->caracter);
    }
    else
    {
        // vai pra o filho da esquerda e coloca 0 na sequencia de bits
        code_so_far[level] = '0';
        travessia(arv->esq, level + 1, code_so_far, codes);

        // vai pra o filho da direita e coloca 1 na sequencia de bits
        code_so_far[level] = '1';
        travessia(arv->dir, level + 1, code_so_far, codes);
    }
}

int tArvEhFolha(tArv *a)
{
    return a->dir == NULL && a->esq == NULL;
}

unsigned char tArvRetornaCaracter(tArv *a)
{
    return a->caracter;
}

tArv *tArvRetornaDireita(tArv *a)
{
    if (tArvEhVazia(a) || tArvEhVazia(a->dir))
    {
        return NULL;
    }
    return a->dir;
}

tArv *tArvRetornaEsquerda(tArv *a)
{
    if (tArvEhVazia(a) || tArvEhVazia(a->esq))
    {
        return NULL;
    }
    return a->esq;
}

int tArvAltura(tArv *a)
{
    if (tArvEhVazia(a))
    {
        return -1;
    }

    int direita = tArvAltura(a->dir);
    int esquerda = tArvAltura(a->esq);

    if (direita > esquerda)
    {
        return direita + 1;
    }
    else
    {
        return 1 + esquerda;
    }
}


int tArvQntFolhas(tArv *a)
{
    int soma = 0;
    if (!tArvEhVazia(a->dir))
    {
        soma = +tArvQntFolhas(a->dir);
    }
    if (!tArvEhVazia(a->esq))
    {
        soma = +tArvQntFolhas(a->esq);
    }
    return soma + 1;
}

void escreveEOFnoArquivo(FILE* arquivo)
{
    fwrite(&eof, sizeof(unsigned char), 1, arquivo);
}

void escreveNoArvore(tArv *arv, FILE *arquivoOutput)
{
    if (tArvEhVazia(arv))
    {
        return;
    }

    if (tArvEhFolha(arv))
    {
        unsigned char byte = 1;
        unsigned char car = tArvRetornaCaracter(arv);
        // Escreve o bit 1 para indicar uma folha
        fwrite(&byte, sizeof(unsigned char), 1, arquivoOutput);
        // Escreve o caractere da folha
        fwrite(&car, sizeof(unsigned char), 1, arquivoOutput);
    }
    else
    {
        unsigned char byte = 0;
        // Escreve o bit 0 para indicar um no interno
        fwrite(&byte, sizeof(unsigned char), 1, arquivoOutput);
        escreveNoArvore(tArvRetornaEsquerda(arv), arquivoOutput);
        escreveNoArvore(tArvRetornaDireita(arv), arquivoOutput);
    }
}

// Função para reconstruir a árvore a partir do arquivo binário
tArv *leNoArvore(FILE *arquivoInput)
{
    unsigned char byte;
    if (fread(&byte, sizeof(unsigned char), 1, arquivoInput) != 1)
    {
        // Erro ao ler o byte, possivelmente fim do arquivo
        return NULL;
    }

    // Cria uma folha
    if (byte == 1)
    {
        unsigned char car;
        if (fread(&car, sizeof(unsigned char), 1, arquivoInput) != 1)
        {
            // Erro ao ler o caractere da folha
            printf("ERRO NO LE ARVORE: Falha ao ler o caractere da folha\n");
            return NULL;
        }

        if (car == 0)
        {
            // Caracter especial indicando fim da árvore
            return NULL;
        }

        tArv *novo = tArvCriaVazia();
        novo->caracter = car;
        return novo;
    }
    // Cria um nó interno
    else
    {
        tArv *esq = leNoArvore(arquivoInput);
        tArv *dir = leNoArvore(arquivoInput);
        tArv *novo = tArvCriaVazia();
        novo->dir = dir;
        novo->esq = esq;
        return novo;
    }
}