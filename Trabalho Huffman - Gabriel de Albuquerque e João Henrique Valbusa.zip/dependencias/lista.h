#ifndef TLISTA
#define TLISTA

typedef struct _tLista tLista;

tLista *tListaCriaVazia();
void tListaInsere(tLista *l, void *dado);
void *tListaRetiraMenor(tLista *l, int compara(void *, void *));
void tListaLibera(tLista *l);
int tListaTamanho(tLista *l);
void tListaOrdena(tLista *l, int compara(void *, void *));
#endif