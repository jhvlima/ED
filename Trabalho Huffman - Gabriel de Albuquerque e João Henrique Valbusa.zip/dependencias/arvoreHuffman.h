/**
 * @file arvoreHuffman.h
 * @brief Arquivo cabecalho para o TAD a arvore Huffman
 *
 *
 * @author Gabriel de Albuquerque
 * @author Joao Henrique
 */

#ifndef ARVOREHUFFMAN_H
#define ARVOREHUFFMAN_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "bitmap.h"
#include "lista.h"

/*-------------------------| Vetor |---------------------------*/
#define TAM_BITMAP 1000000000
#define QNT_CARACTERES 257

/**
 * @brief Cada ocorrencia do caracter ascii no texto do arquivo incrementa +1 na posicao do vetor que representa aquele caracter
 * 
 * @return Retorna 0 se deu certo, se não retorna 1
 */
int preencheVetorPesos(int vetor[], FILE *arquivo);


/*-------------------------| Arvore |---------------------------*/

typedef struct _tArv tArv;

// Cria uma árvore vazia
tArv* tArvCriaVazia ();

// cria uma árvore pai, com subárvore esquerda e e subárvore direita d
tArv* tArvInsere (tArv* e, tArv* d);

// libera o espaço de memória ocupado pela árvore a
void tArvLibera (tArv* a);

// retorna true se a árvore estiver vazia e false caso contrário
int tArvEhVazia (tArv* a);

// indica a ocorrência (1) ou não (0) do caracter c
int tArvPertence (tArv* a, int dado);

// imprime as informações dos nós da árvore
void tArvImprime (tArv* a);

// Cria a lista de arvores, comecando com todas elas sendo folhas, e postoeriormente será unido as duas menores frequencias ao uma nova arvore pai
tLista *tListaCriaArvoresHuff(int *vetorPeso);

// Cria a arvore apartir do vetor de pesos dos bytes
tArv *tArvCriaArvoreHuff(int *vetorPeso);

// retorna true se a árvore for folha e false caso contrário
int tArvEhFolha(tArv *a);

// retorna o caracter da arovre (informacao)
unsigned char tArvRetornaCaracter(tArv *a);

// retorna o filho da direita
tArv *tArvRetornaDireita(tArv *a);

// retorna o filho da esquerda
tArv *tArvRetornaEsquerda(tArv *a);

// codifica o conteudo do infile para o outfile usando a travessia de cada folha da arvore de huffmam que esta no codes
void codificarArquivo(FILE *infile, FILE *outfile, char *codes[], bitmap *bm, unsigned char *current_byte, unsigned int *nbits);

/**
 * @brief coloca o caminho da raiz até cada folha no vetor codes
 * 	O indice do vetor corresponde ao valor ascii do caracter
 *  
 * 	@param level current level in Huffman tree 
 * 	@param  codes vetor com 256 posicoes o indice é o caracter e o conteudo é o caminho da raiz até a folha que contem esse caracter
 * 	composto por 0 e 1
 * 	@param  code_so_far string que guarda  
 */
void travessia (tArv *r, int level, char *code_so_far, char **codes);

// retorna o tamanho da arvore
int tArvAltura(tArv *a);

// retorna a quantidade de folhas da arvore
int tArvQntFolhas(tArv *a);

tArv *reconstruirArvore(FILE *arquivoInput, unsigned char *current_byte, unsigned int *currentBitPos);

tArv *leNoArvore(FILE *arquivoInput);

void escreveNoArvore(tArv *arv, FILE *arquivoOutput);

void escreveEOFnoArquivo(FILE* arquivo);

#endif