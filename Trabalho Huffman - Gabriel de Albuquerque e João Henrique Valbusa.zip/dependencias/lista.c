#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "lista.h"

typedef struct _tNode tNode;

struct _tNode
{
    void *dado;
    tNode *proximoNode;
};

// sentinela
struct _tLista
{
    tNode *primeiroNode;
    tNode *ultimoNode;
    int tamanho;
};

tLista *tListaCriaVazia()
{
    tLista *lista = calloc(1, sizeof(tLista));
    lista->primeiroNode = lista->ultimoNode = NULL;
    lista->tamanho = 0;
    return lista;
}

void tListaInsere(tLista *lista, void *dado)
{
    if (dado == NULL)
    {
        printf("Produto inexistente\n");
    }
    if (lista == NULL)
    {
        printf("Lista inexistente\n");
    }

    tNode *novoNode = calloc(1, sizeof(tNode));

    // nao tem nenhum node
    if (!lista->ultimoNode)
    {
        lista->primeiroNode = lista->ultimoNode = novoNode;
    }

    else
    {
        lista->ultimoNode->proximoNode = novoNode;
        lista->ultimoNode = lista->ultimoNode->proximoNode;
    }

    lista->ultimoNode->dado = dado;
    lista->ultimoNode->proximoNode = NULL;
    lista->tamanho++;
}

// retira o primeiro da lista
void *tListaRetiraMenor(tLista *lista, int compara(void *, void *))
{
    if (lista == NULL || lista->primeiroNode == NULL)
    {
        return NULL;
    }

    tNode *anterior = NULL;
    tNode *atual = lista->primeiroNode;
    tNode *menorNode = lista->primeiroNode;
    tNode *anteriorMenor = NULL;

    while (atual != NULL)
    {
        if (compara(atual->dado, menorNode->dado) < 0)
        {
            menorNode = atual;
            anteriorMenor = anterior;
        }
        anterior = atual;
        atual = atual->proximoNode;
    }

    if (anteriorMenor == NULL)
    {
        lista->primeiroNode = menorNode->proximoNode;
    }
    else
    {
        anteriorMenor->proximoNode = menorNode->proximoNode;
    }

    if (menorNode == lista->ultimoNode)
    {
        lista->ultimoNode = anteriorMenor;
    }

    void *dado = menorNode->dado;
    free(menorNode);
    lista->tamanho--;
    return dado;
}

void tListaLibera(tLista *lista)
{
    tNode *atual = lista->primeiroNode;
    // o segundo node vira o inico da lista e libera o antigo primeiro
    while (atual)
    {
        lista->primeiroNode = atual->proximoNode;
        free(atual);
        atual = lista->primeiroNode;
    }
    free(lista);
}

int tListaTamanho(tLista *l)
{
    return l->tamanho;
}

// a primeira posicao tem o arvore com menor ocorrencia
void tListaOrdena(tLista *lista, int compara(void *, void *))
{
    if (lista == NULL || lista->primeiroNode == NULL)
    {
        return;
    }

    for (tNode *i = lista->primeiroNode; i != NULL; i = i->proximoNode)
    {
        for (tNode *j = i->proximoNode; j != NULL; j = j->proximoNode)
        {
            if (compara(i->dado, j->dado) > 0)
            {
                void *temp = i->dado;
                i->dado = j->dado;
                j->dado = temp;
            }
        }
    }
}