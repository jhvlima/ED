#include "bitmap.h"
#include <stdio.h>
#include <stdlib.h>

/*	Breve explicação do bitmap

	valores em hexadecimal: 	8	9	4	0  -> isso seria imprimido depois de decoficar os bits 
				 			  ______________
	valores dentro do bitmap: |1000 1001 01|00 0000 -> o resto dos zeros foi inicializado ao criar o bitmap
				  			  --------------
									^
									|
									bitmap de tamahno 10
	
	Vamos usar bitmap de 1 mb de tamanho
*/


int main(void) {
	puts("Comecando o teste do bitmap"); /* prints  */

	bitmap* bm=bitmapInit(10);
	printf("size=%d bits\n", bitmapGetMaxSize(bm));
	bitmapAppendLeastSignificantBit(bm, 1);
	bitmapAppendLeastSignificantBit(bm, 0);
	bitmapAppendLeastSignificantBit(bm, 0);
	bitmapAppendLeastSignificantBit(bm, 0);
	bitmapAppendLeastSignificantBit(bm, 1);
	bitmapAppendLeastSignificantBit(bm, 0);
	bitmapAppendLeastSignificantBit(bm, 0);
	bitmapAppendLeastSignificantBit(bm, 1);
	bitmapAppendLeastSignificantBit(bm, 0);
	bitmapAppendLeastSignificantBit(bm, 1);

	printf("%0xh\n", bitmapGetContents(bm)[0]);
	printf("%0xh\n", bitmapGetContents(bm)[1]);
	printf("length=%0d\n", bitmapGetLength(bm));

	int i;
	for (i=0; i<bitmapGetLength(bm); i++) {
		printf("bit #%d = %0xh\n", i, bitmapGetBit(bm, i));
	}

    bitmapLibera(bm);

	puts("Encerrando o teste do bitmap");
	return EXIT_SUCCESS;

}
