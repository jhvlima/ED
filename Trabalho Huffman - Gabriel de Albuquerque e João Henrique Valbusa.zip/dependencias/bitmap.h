/** Define um TAD representando um mapa de bits.
 * @file bitmap.h
 * @author Joao Paulo Andrade Almeida (jpalmeida@inf.ufes.br)
 */

#ifndef BITMAP_H_
#define BITMAP_H_

#include <stdio.h>

/**
 * Estrutura para representar um mapa de bits.
 */
typedef struct map bitmap;

void assert(int testresult, char *message);
unsigned char* bitmapGetContents(bitmap* bm);
unsigned int bitmapGetMaxSize(bitmap* bm);
unsigned int bitmapGetLength(bitmap* bm);
bitmap* bitmapInit(unsigned int max_size);
unsigned char bitmapGetBit(bitmap* bm, unsigned int index);
void bitmapAppendLeastSignificantBit(bitmap* bm, unsigned char bit);
void bitmapLibera (bitmap* bm);


// Function to read individual bits from bitmap
void bitin(bitmap *bm, unsigned char *current_byte, unsigned int *nbits, char *bit);

// Função modificada para adicionar bits ao mapa de bits e qunado o byte estiver completo insere no map
void insereBitNoByte(bitmap *bm, char novoBit, unsigned char *current_byte, unsigned int *nbits);

void insereByteNoBitmap(bitmap *bm, unsigned char novoByte, unsigned char *current_byte, unsigned int *nbits);

// Função para finalizar a escrita do último byte
void imprimeBitmap(FILE *outputFile, bitmap *bm, unsigned char *current_byte, unsigned int *nbits);

unsigned int ehBitUm(unsigned char caracter, int posicao);

#endif /*BITMAP_H_*/
