#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "descompactador.h"

// Função para codificar o arquivo usando os códigos de Huffman

int main(int argc, char *argv[])
{
    // Verifica se os argumentos forma passados corretamente
    if (argc != 2) {
        fprintf(stderr, "ERRO AO USAR O DESCOMPACTADOR:\n USAGE: ./descompactador nome_arquivo.txt\n");
        return EXIT_FAILURE;
    }

    // Abre o arquivo compactado
    char arquivoCompacto[1024];
    snprintf(arquivoCompacto, sizeof(arquivoCompacto), "%s.comp", argv[1]);
    FILE *arquivoInput = fopen(arquivoCompacto, "rb");
    if (arquivoInput == NULL) {
        fprintf(stderr, "ERRO AO ABRIR O ARQUIVO DE INPUT\n");
        return EXIT_FAILURE;
    }

    unsigned char eof;
    if (fread(&eof, sizeof(unsigned char), 1, arquivoInput) != 1) {
        fprintf(stderr, "ERRO AO LER O MARCADOR DE EOF\n");
        fclose(arquivoInput);
        return EXIT_FAILURE;
    }

    // Lê a árvore de Huffman do início do arquivo
    tArv *arvHuffman = leNoArvore(arquivoInput);
    if (arvHuffman == NULL) {
        fprintf(stderr, "ERRO AO LER A ARVORE DE HUFFMAN\n");
        fclose(arquivoInput);
        return EXIT_FAILURE;
    }

    // Imprime a árvore de Huffman para debug
    tArvImprime(arvHuffman);

    // Abre o arquivo de saída
    char arquivoDescompacto[1024];
    snprintf(arquivoDescompacto, sizeof(arquivoDescompacto), "%s.descomp", argv[1]);
    FILE *arquivoOutput = fopen(arquivoDescompacto, "wb");
    if (arquivoOutput == NULL) {
        fprintf(stderr, "ERRO AO ABRIR O ARQUIVO DE OUTPUT\n");
        tArvLibera(arvHuffman);
        fclose(arquivoInput);
        return EXIT_FAILURE;
    }

    // Lê os dados do arquivo binário e imprime na saída
    unsigned char caracter;
    tArv *auxiliar = arvHuffman;
    int eof_reached = 0;

    while (fread(&caracter, sizeof(unsigned char), 1, arquivoInput)) {
        for (int i = 7; i >= 0; i--) {
            if (ehBitUm(caracter, i)) {
                auxiliar = tArvRetornaDireita(auxiliar);
            } else {
                auxiliar = tArvRetornaEsquerda(auxiliar);
            }

            // Verifica se auxiliar é NULL
            if (auxiliar == NULL) {
                fprintf(arquivoOutput, "Erro: Caminho invalido na arvore de Huffman.\n");
                tArvLibera(arvHuffman);
                fclose(arquivoOutput);
                fclose(arquivoInput);
                return EXIT_FAILURE;
            }

            if (tArvEhFolha(auxiliar)) {
                unsigned char caracterDecodificado = tArvRetornaCaracter(auxiliar);
                if (caracterDecodificado == eof) {
                    eof_reached = 1;
                    break;
                }
                fwrite(&caracterDecodificado, sizeof(unsigned char), 1, arquivoOutput);
                auxiliar = arvHuffman;
            }
        }
        if (eof_reached) {
            break;
        }
    }

    fclose(arquivoOutput);
    fclose(arquivoInput);
    tArvLibera(arvHuffman);

    return EXIT_SUCCESS;
}
