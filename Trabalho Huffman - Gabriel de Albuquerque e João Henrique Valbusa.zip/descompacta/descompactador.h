/**
 * @file descompactador.h
 * @brief Arquivo de cabeçalho para o descompactador de Huffman
 *
 *
 * @author Gabriel de Albuquerque
 * @author Joao Henrique
 */

#ifndef DESCOMPACTADOR_H
#define DESCOMPACTADOR_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "../dependencias/arvoreHuffman.h"

/**
 * @brief Constroi e retorna a arovre de huffman do arquivo binario compactado
 */
tArv *tArvConstroiDoBiniario(FILE *arquivo);

unsigned int ehBitUm(unsigned char caracter, int posicao);

#endif