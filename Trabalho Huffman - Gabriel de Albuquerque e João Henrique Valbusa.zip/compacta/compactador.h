/**
 * @file compactador.h
 * @brief Arquivo de cabeçalho para o compactador de Huffman
 *
 *
 * @author Gabriel de Albuquerque
 * @author Joao Henrique
 */

#ifndef COMPACTADOR_H
#define COMPACTADOR_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "../dependencias/arvoreHuffman.h"


#endif