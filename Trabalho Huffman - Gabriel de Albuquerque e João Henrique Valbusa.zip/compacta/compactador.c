/**
 * @file compactador.c
 * @brief Arquivo fonte para o compactador de Huffman
 *
 *
 * @author Gabriel de Albuquerque
 * @author Joao Henrique
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "compactador.h"

int main(int argc, char *argv[])
{
    // verifica se os argumentos forma passados corretamente
    assert(argc == 2, "ERRO AO USAR O COMPACTADOR:\n USAGE: ./compactador nome_arquivo.txt");

    // gera o vetor de ocorrencia de todos os carateres no arquivo, fazendo a primeira leitura do arquivo de input
    int *pesoCaracteres = calloc(QNT_CARACTERES, sizeof(int));
    FILE *arquivoInput = fopen(argv[1], "rb");
    assert(arquivoInput != NULL, "ERRO AO ABRIR O ARQUIVO");
    int n = preencheVetorPesos(pesoCaracteres, arquivoInput);
    fclose(arquivoInput);

    // imprime o vetor no nouhup para ver funciona


    // gera arvore de huffman com o vetor de pesos
    tArv *arvHuffman = tArvCriaArvoreHuff(pesoCaracteres);
    int altura = tArvAltura(arvHuffman);
    free(pesoCaracteres);

    // variaveis para usar bits
    char **codes = calloc(QNT_CARACTERES, sizeof(char *));
    char *code = calloc(1, sizeof(char*));
    travessia(arvHuffman, 0, code, codes);
    tArvImprime(arvHuffman); // imprime no nouhup para ver funciona
    free(code);

    // Encontra uma sequencia de bits nao usada para indicar fim de arquivo

    // abre o arquivo binario (compactado)
    char arquivoCompacto[1024];
    snprintf(arquivoCompacto, sizeof(arquivoCompacto), "%s.comp", argv[1]);
    FILE *arquivoOutput = fopen(arquivoCompacto, "wb");
    assert(arquivoOutput != NULL, "ERRO AO ABRIR O ARQUIVO DE OUTPUT");

    // Inicializar o mapa de bits com um tamanho máximo estimado
    unsigned char *current_byte = calloc(1, sizeof(unsigned char));
    unsigned int *nbits = calloc(1, sizeof(unsigned int));
    bitmap *bm = bitmapInit(TAM_BITMAP);

    // imprime a arvore no arquivo binario (usando o bitmap)
    escreveEOFnoArquivo(arquivoOutput);
    escreveNoArvore(arvHuffman, arquivoOutput);

    // faz a segunda leitura do arquivo de input para realmente codificar os bits
    arquivoInput = fopen(argv[1], "rb");
    assert(arquivoInput != NULL, "ERRO AO ABRIR O ARQUIVO");

    // imprime dados no arquivo binario (usando o bitmap)
    codificarArquivo(arquivoInput, arquivoOutput, codes, bm, current_byte, nbits);

    // Liberar a memória do mapa de bits
    free(current_byte);
    free(nbits);
    bitmapLibera(bm);
    fclose(arquivoInput);
    fclose(arquivoOutput);
    tArvLibera(arvHuffman);
    
    // desaloca o programa
    for (int i = 0; i < QNT_CARACTERES; i++)
    {
        free(codes[i]);
    }
    free(codes);
    return 0;
}
